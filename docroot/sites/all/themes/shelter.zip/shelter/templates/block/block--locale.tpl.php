<?php

/**
 * @file
 * Default theme implementation to display a block.
 */
?>
<?php print $content ?>
