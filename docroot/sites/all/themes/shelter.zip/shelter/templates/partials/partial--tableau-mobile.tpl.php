<div id="tableau-mobile" class='tableauPlaceholder' style='width: 320px; height: 1189px;'>
  <object class='tableauViz' width='320' height='1189' style='display:none;'>
    <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F' />
    <param name='site_root' value='' />
    <param name='name' value='HomeDashboard-320&#47;Dashboard320' />
    <param name='tabs' value='no' /><param name='toolbar' value='yes' />
    <param name='animate_transition' value='yes' />
    <param name='display_static_image' value='no' />
    <param name='display_spinner' value='yes' />
    <param name='display_overlay' value='yes' />
    <param name='display_count' value='yes' />
    <param name='showVizHome' value='no' />
    <param name='showTabs' value='y' />
  </object>
</div>
