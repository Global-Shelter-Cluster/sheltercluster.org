<div id="tableau-tablet" class='tableauPlaceholder' style='width: 768px; height: 1069px;'>
  <object class='tableauViz' width='768' height='1069' style='display:none;'>
    <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F' />
    <param name='site_root' value='' />
    <param name='name' value='HomeDashboard-764&#47;Dashboard764' />
    <param name='tabs' value='no' />
    <param name='toolbar' value='yes' />
    <param name='animate_transition' value='yes' />
    <param name='display_static_image' value='no' />
    <param name='display_spinner' value='yes' />
    <param name='display_overlay' value='yes' />
    <param name='display_count' value='yes' />
    <param name='showVizHome' value='no' />
    <param name='showTabs' value='y' />
  </object>
</div>
