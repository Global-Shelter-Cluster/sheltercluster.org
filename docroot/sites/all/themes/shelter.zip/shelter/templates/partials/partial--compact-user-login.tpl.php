<div id="user-login-container" class="clearfix">
  <?php print render($user_login); ?>
</div>
