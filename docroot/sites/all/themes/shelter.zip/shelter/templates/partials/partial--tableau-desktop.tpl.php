<div id="tableau-desktop" class='tableauPlaceholder' style='width: 1004px; height: 1069px;'>
  <object class='tableauViz' width='1004' height='1069' style='display:none;'>
    <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F' />
    <param name='site_root' value='' />
    <param name='name' value='HomeDashboard-1000&#47;Dashboard1000' />
    <param name='tabs' value='no' /><param name='toolbar' value='yes' />
    <param name='static_image' value='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ho&#47;HomeDashboard-1000&#47;Dashboard1000&#47;1.png' />
    <param name='animate_transition' value='yes' />
    <param name='display_static_image' value='no' />
    <param name='display_spinner' value='yes' />
    <param name='display_overlay' value='yes' />
    <param name='display_count' value='yes' />
    <param name='showVizHome' value='no' />
    <param name='showTabs' value='y' />
  </object>
</div>
