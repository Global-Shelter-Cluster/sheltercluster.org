<div id="bandwidth-selector">
  <?php print _svg('icons/signal', array('id' => 'bandwidth-selector-icon', 'alt' => 'Bandwidth indication icon')); ?>
  <a href="" class="active">Low bandwidth environment</a>
  <span>/</span>
  <a href="">Switch to high</a>
</div>