<ul class="posters clearfix">
  <li class="poster">
    <?php print theme('image', array(
      'path' => drupal_get_path('theme', 'shelter') . '/assets/images/posters/livelihoods.jpg',
    )); ?>
  </li>
  <li class="poster">
    <?php print theme('image', array(
      'path' => drupal_get_path('theme', 'shelter') . '/assets/images/posters/shelter-means-home.jpg',
    )); ?>
  </li>
  <li class="poster">
    <?php print theme('image', array(
      'path' => drupal_get_path('theme', 'shelter') . '/assets/images/posters/shelter-supports-protection.jpg',
    )); ?>
  </li>
</ul>
