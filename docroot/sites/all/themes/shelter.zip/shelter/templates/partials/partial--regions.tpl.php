<section class="page-margin">
  <?php print render($page['footer']['menu_regions']); ?>
</section>
