<li class="operation-teaser">
  <?php print l($title, 'node/' . $nid); ?>
</li>
