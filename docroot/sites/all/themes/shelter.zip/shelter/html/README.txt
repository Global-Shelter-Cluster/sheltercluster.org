
This directory keeps original html static files for development reference.