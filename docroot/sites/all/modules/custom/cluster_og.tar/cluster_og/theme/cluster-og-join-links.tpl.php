<h3 data-collapsible="join-group" data-collapsible-default="collapsed"><?php print $header; ?></h3>
<section id="join-group" class="clearfix">
  <p><?php print $instructions; ?></p>
  <div id="button-join-group"><?php print $link;?></div>
</section>
