Provides the Document content type implementation.
Exposes documents as cards to the theme layer, grouped by vocabularies.
Uses the field_group module to group documents by vocabularies.
Provides path alias and menu callback for document page for groups.